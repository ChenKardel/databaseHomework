CREATE VIEW V_STU_LESSON AS
  select 
student.STUDENTNUM, 
STUDENTNAME, 
lesson.lessonnum, 
LESSONNAME, 
CREDIT, 
teacher.teachernum,
TEACHERNAME 
from STU_CHOOSE_LESSON join STUDENT on student.studentnum = STU_CHOOSE_LESSON.STUDENTNUM JOIN LESSON on lesson.lessonnum = LESSON.LESSONNUM join teacher on lesson.teachernum = teacher.teachernum
/

