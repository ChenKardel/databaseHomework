CREATE PROCEDURE leave_apply_stat_proc IS

vLeave_apply_situation LEAVE_APPLY.STUDENTNUM%TYPE;
vCurrent_value number(2);
vTimes LEAVE_APPLY_STAT.STUDENTNUM%TYPE;
CURSOR leave_apply_studentnum IS
       select studentnum, count(studentnum) as c from leave_apply group by studentnum;BEGIN
OPEN leave_apply_studentnum;
LOOP
  FETCH leave_apply_studentnum
        INTO vLeave_apply_situation, vTimes;
  EXIT WHEN leave_apply_studentnum%NOTFOUND;
  insert into leave_apply_stat values(vLeave_apply_situation, vTimes);
END LOOP;
IF leave_apply_studentnum%ISOPEN THEN CLOSE leave_apply_studentnum; END IF;
END;
/

