CREATE TRIGGER TRI_UPDATE
  AFTER UPDATE OF STATE
  ON LEAVE_APPLY
  FOR EACH ROW
  declare
  -- local variables here
  vContent varchar2(100);
  dateString DATE := sysdate;
begin
  vContent := '同学你好，你的申请单'||:new.state;
  select sysdate into dateString from dual;
  dbms_output.put_line('trigger the tri_update');
  insert into message values(messageNumSequence.Nextval, vContent, :new.applynum, :new.studentnum, dateString);
end tri_update;
/

