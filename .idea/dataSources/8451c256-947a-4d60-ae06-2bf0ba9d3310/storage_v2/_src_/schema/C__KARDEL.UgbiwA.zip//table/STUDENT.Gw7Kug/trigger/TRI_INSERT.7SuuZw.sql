CREATE TRIGGER TRI_INSERT
  BEFORE INSERT
  ON STUDENT
  FOR EACH ROW
  declare
  -- local variables here
begin
  dbms_output.put_line('start use trigger');
  if :n.class = 99
    then :n.class := 1;
  end if;  
       
end tri_insert;
/

